# 🚀 DAREWHEEL - DEVELOPMENT KICKOFF GUIDE

**Status:** Development Starting Now  
**Date:** March 27, 2026  
**Estimated Duration:** 4 Months (MVP)  
**Team Size:** 4-6 developers

---

## 📋 TABLE OF CONTENTS

1. [Pre-Setup Checklist](#pre-setup-checklist)
2. [Environment Setup](#environment-setup)
3. [Project Initialization](#project-initialization)
4. [Database Setup](#database-setup)
5. [Backend Setup](#backend-setup)
6. [Frontend Setup](#frontend-setup)
7. [Docker Setup](#docker-setup)
8. [Development Workflow](#development-workflow)
9. [Git Strategy](#git-strategy)
10. [Testing & QA](#testing--qa)

---

## ✅ PRE-SETUP CHECKLIST

### **Required Tools**

```bash
□ Node.js 18+ (https://nodejs.org/)
□ npm 9+ or yarn 3+
□ PostgreSQL 14+ (https://www.postgresql.org/download/)
□ Redis 7+ (https://redis.io/download)
□ Docker & Docker Compose (optional but recommended)
□ Git (https://git-scm.com/)
□ VS Code or IDE of choice
□ Postman/Insomnia (API testing)
□ GitHub account (for repository)

Verify installations:
node --version        # v18.0.0+
npm --version         # 9.0.0+
postgres --version    # 14.0+
redis-cli --version   # 7.0.0+
docker --version      # 20.10.0+
git --version         # 2.30.0+
```

### **Required Accounts**

```
□ GitHub account (code repository)
□ Vercel account (frontend hosting)
□ Railway/Render account (backend hosting)
□ AWS account (S3 for images)
□ Sendgrid account (email service)
□ Stripe account (payments - Phase 2)
```

### **Hardware Requirements**

```
Development Machine:
- RAM: 8GB minimum (16GB recommended)
- Disk Space: 10GB free
- CPU: Intel i5/AMD Ryzen 5 equivalent
- Internet: 10+ Mbps

All team members should have similar setup
```

---

## 🔧 ENVIRONMENT SETUP

### **1. Clone Repository**

```bash
# Create workspace
mkdir ~/darewheel-workspace
cd ~/darewheel-workspace

# Initialize git repository
git init darewheel
cd darewheel

# Create initial commit
git add .
git commit -m "Initial commit"

# Add GitHub remote
git remote add origin https://github.com/YOUR_USERNAME/darewheel.git
git branch -M main
git push -u origin main
```

### **2. Environment Variables**

#### **Backend .env file**

```bash
# Create: backend/.env

# ============================================
# APPLICATION
# ============================================
NODE_ENV=development
PORT=5000
BACKEND_URL=http://localhost:5000
FRONTEND_URL=http://localhost:3000
LOG_LEVEL=debug

# ============================================
# DATABASE - PostgreSQL
# ============================================
DB_HOST=localhost
DB_PORT=5432
DB_NAME=darewheel_dev
DB_USER=darewheel_user
DB_PASSWORD=SecurePassword123!
DB_POOL_MIN=2
DB_POOL_MAX=10

# ============================================
# CACHE - Redis
# ============================================
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_DB=0
REDIS_URL=redis://localhost:6379/0

# ============================================
# AUTHENTICATION
# ============================================
JWT_SECRET=your_jwt_secret_key_change_this_in_production
JWT_EXPIRY=15m
JWT_REFRESH_SECRET=your_refresh_secret_key_change_this_in_production
JWT_REFRESH_EXPIRY=7d
BCRYPT_ROUNDS=12

# ============================================
# SOCKET.IO
# ============================================
SOCKET_IO_PORT=5000
SOCKET_IO_CORS_ORIGIN=http://localhost:3000
SOCKET_IO_PING_INTERVAL=25000
SOCKET_IO_PING_TIMEOUT=60000

# ============================================
# STORAGE - AWS S3
# ============================================
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret
AWS_REGION=us-east-1
AWS_S3_BUCKET=darewheel-bucket
AWS_S3_URL=https://darewheel-bucket.s3.amazonaws.com

# ============================================
# EMAIL - SendGrid
# ============================================
SENDGRID_API_KEY=your_sendgrid_key
SENDGRID_FROM_EMAIL=noreply@darewheel.app

# ============================================
# STRIPE - Payments (Phase 2)
# ============================================
STRIPE_SECRET_KEY=your_stripe_key
STRIPE_PUBLISHABLE_KEY=your_stripe_pub_key
STRIPE_WEBHOOK_SECRET=your_webhook_secret

# ============================================
# MONITORING
# ============================================
SENTRY_DSN=your_sentry_dsn
DATADOG_API_KEY=your_datadog_key

# ============================================
# FEATURE FLAGS
# ============================================
FEATURE_PREMIUM=false
FEATURE_ANALYTICS=true
FEATURE_USER_QUESTIONS=false
FEATURE_REFERRAL=false
```

#### **Frontend .env file**

```bash
# Create: frontend/.env.local

# ============================================
# API
# ============================================
VITE_API_URL=http://localhost:5000
VITE_SOCKET_URL=http://localhost:5000
VITE_ENV=development

# ============================================
# FEATURES
# ============================================
VITE_ENABLE_ANALYTICS=true
VITE_ENABLE_PREMIUM=false
VITE_MAX_ROOM_SIZE=50

# ============================================
# THIRD PARTY
# ============================================
VITE_STRIPE_PUBLIC_KEY=your_stripe_pub_key
VITE_SENTRY_DSN=your_sentry_dsn

# ============================================
# BUILD
# ============================================
VITE_BUILD_SOURCEMAP=true
```

#### **Database .env file**

```bash
# Create: backend/.env.database

POSTGRES_USER=darewheel_user
POSTGRES_PASSWORD=SecurePassword123!
POSTGRES_DB=darewheel_dev
POSTGRES_INITDB_ARGS=--encoding=UTF8
```

### **3. Create .env.example files** (for team)

```bash
# backend/.env.example (commit to git)
# Copy of .env but with placeholder values
# This helps team members see what env vars are needed

NODE_ENV=development
PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=darewheel_dev
DB_USER=darewheel_user
DB_PASSWORD=your_password_here
# ... etc
```

---

## 🗂️ PROJECT INITIALIZATION

### **1. Create Folder Structure**

```bash
# From darewheel/ directory

# Create main directories
mkdir -p frontend backend docs tests

# Backend structure
mkdir -p backend/{src,tests,docs}
mkdir -p backend/src/{config,routes,controllers,services,models,middleware,socket,utils,database}

# Frontend structure
mkdir -p frontend/{src,public,tests}
mkdir -p frontend/src/{pages,components,hooks,store,services,styles,utils,assets}

# Shared documentation
mkdir -p docs/{API,DATABASE,DEPLOYMENT}

# Create README files
cat > README.md << 'EOF'
# 🎡 DareWheel

The ultimate dual-mode (offline/online) Truth or Dare gaming platform.

## Quick Start

See [DEVELOPMENT.md](./docs/DEVELOPMENT.md) for setup instructions.

## Documentation

- [Architecture](./docs/ARCHITECTURE.md)
- [API Documentation](./docs/API/README.md)
- [Database Schema](./docs/DATABASE/schema.md)
- [Deployment](./docs/DEPLOYMENT/README.md)

## Tech Stack

- Frontend: React 18 + Vite + TailwindCSS
- Backend: Node.js + Express.js + Socket.io
- Database: PostgreSQL + Redis
- Infrastructure: Docker + AWS

## Team

See TEAM.md for contributor information.

## License

MIT License - See LICENSE file
EOF

cat > .gitignore << 'EOF'
# Environment
.env
.env.local
.env.*.local

# Dependencies
node_modules/
/.pnp
.pnp.js

# Testing
coverage/
.nyc_output/

# Production
/build
/dist
.next/
out/

# Misc
.DS_Store
*.pem
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.idea/
.vscode/*
!.vscode/settings.json
*.swp
*.swo

# IDE
.vscode/
.idea/

# OS
Thumbs.db
.DS_Store

# Logs
logs/
*.log

# Temp
tmp/
temp/
EOF
```

### **2. Initialize Git**

```bash
# Initialize git repo (if not done)
git init
git add .
git commit -m "Initial project structure"

# Create main branches
git branch develop
git branch -M main
git checkout develop

# Push to GitHub
git remote add origin https://github.com/YOUR_USERNAME/darewheel.git
git push -u origin main
git push -u origin develop
```

---

## 💾 DATABASE SETUP

### **1. PostgreSQL Installation**

```bash
# macOS (using Homebrew)
brew install postgresql@14
brew services start postgresql@14

# Ubuntu/Debian
sudo apt-get install postgresql postgresql-contrib
sudo systemctl start postgresql

# Windows
# Download from https://www.postgresql.org/download/windows/
# Run installer and follow instructions
```

### **2. Create Database and User**

```bash
# Connect to PostgreSQL
psql postgres

# Inside psql:
CREATE USER darewheel_user WITH PASSWORD 'SecurePassword123!';
CREATE DATABASE darewheel_dev OWNER darewheel_user;
ALTER ROLE darewheel_user WITH CREATEDB;

# Grant permissions
GRANT ALL PRIVILEGES ON DATABASE darewheel_dev TO darewheel_user;
\q

# Verify connection
psql -U darewheel_user -d darewheel_dev -h localhost
```

### **3. Redis Installation**

```bash
# macOS
brew install redis
brew services start redis

# Ubuntu/Debian
sudo apt-get install redis-server
sudo systemctl start redis-server

# Windows (using WSL2 or Docker)
docker run -d -p 6379:6379 redis:7-alpine

# Verify
redis-cli ping
# Expected output: PONG
```

### **4. Database Migrations (Backend)**

```bash
# Create migration directory
mkdir -p backend/src/database/migrations
mkdir -p backend/src/database/seeds

# Create migration script
cat > backend/src/database/migrations/001_create_users.sql << 'EOF'
-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  avatar_url VARCHAR(255),
  date_of_birth DATE,
  preferred_language VARCHAR(10) DEFAULT 'en',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE,
  last_login TIMESTAMP,
  
  CONSTRAINT email_valid CHECK (email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$')
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_active ON users(is_active);
EOF

# Run migrations
psql -U darewheel_user -d darewheel_dev -f backend/src/database/migrations/001_create_users.sql

# Verify
psql -U darewheel_user -d darewheel_dev -c "\dt"
```

---

## 🖥️ BACKEND SETUP

### **1. Initialize Node Project**

```bash
cd backend

# Initialize package.json
npm init -y

# Install core dependencies
npm install express socket.io pg redis dotenv cors helmet morgan winston

# Install dev dependencies
npm install -D nodemon jest supertest @types/node typescript ts-node

# Create tsconfig.json
cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "lib": ["ES2020"],
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "moduleResolution": "node"
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "tests"]
}
EOF

# Create basic project structure
mkdir -p src/{config,routes,controllers,services,models,middleware,socket,utils}

# Create .gitkeep files
touch src/{config,routes,controllers,services,models,middleware,socket,utils}/.gitkeep
```

### **2. Create Server Entry Point**

```bash
cat > src/index.ts << 'EOF'
import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { Server as SocketIOServer } from 'socket.io';
import http from 'http';
import dotenv from 'dotenv';
import logger from './utils/logger';

// Load environment variables
dotenv.config();

// Initialize Express app
const app: Express = express();
const server = http.createServer(app);

// Initialize Socket.io
const io = new SocketIOServer(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST']
  }
});

// ============================================
// MIDDLEWARE
// ============================================
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============================================
// ROUTES
// ============================================
app.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// ============================================
// SOCKET.IO EVENTS
// ============================================
io.on('connection', (socket) => {
  logger.info(`User connected: ${socket.id}`);

  socket.on('disconnect', () => {
    logger.info(`User disconnected: ${socket.id}`);
  });
});

// ============================================
// ERROR HANDLING
// ============================================
app.use((err: any, req: Request, res: Response) => {
  logger.error(err);
  res.status(500).json({
    error: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error'
  });
});

// ============================================
// START SERVER
// ============================================
const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
  logger.info(`🚀 Server running on port ${PORT}`);
  logger.info(`📡 Socket.io ready for connections`);
});

export { app, io };
EOF

# Create logger utility
mkdir -p src/utils
cat > src/utils/logger.ts << 'EOF'
import winston from 'winston';

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    }),
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});

export default logger;
EOF

# Create logs directory
mkdir -p logs
```

### **3. Update package.json scripts**

```bash
cat > package.json << 'EOF'
{
  "name": "darewheel-backend",
  "version": "1.0.0",
  "description": "DareWheel Backend Server",
  "main": "dist/index.js",
  "scripts": {
    "dev": "nodemon --exec ts-node src/index.ts",
    "build": "tsc",
    "start": "node dist/index.js",
    "test": "jest",
    "test:watch": "jest --watch",
    "lint": "eslint src/**/*.ts",
    "db:migrate": "psql -U $DB_USER -d $DB_NAME -f src/database/migrations/001_create_users.sql",
    "db:seed": "ts-node src/database/seeds/seed.ts"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "dotenv": "^16.0.3",
    "express": "^4.18.2",
    "helmet": "^7.0.0",
    "morgan": "^1.10.0",
    "pg": "^8.8.0",
    "redis": "^4.6.0",
    "socket.io": "^4.6.0",
    "winston": "^3.8.1"
  },
  "devDependencies": {
    "@types/express": "^4.17.17",
    "@types/jest": "^29.5.0",
    "@types/node": "^18.15.0",
    "jest": "^29.5.0",
    "nodemon": "^2.0.22",
    "supertest": "^6.3.3",
    "ts-jest": "^29.1.0",
    "ts-node": "^10.9.1",
    "typescript": "^5.0.0"
  }
}
EOF
```

### **4. Start Backend**

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Expected output:
# 🚀 Server running on port 5000
# 📡 Socket.io ready for connections
```

---

## 🎨 FRONTEND SETUP

### **1. Create React App with Vite**

```bash
cd frontend

# Create Vite project
npm create vite@latest . -- --template react-ts

# Install dependencies
npm install

# Install additional packages
npm install socket.io-client axios zustand framer-motion

# Install Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# Install development tools
npm install -D @types/react @types/react-dom typescript
```

### **2. Tailwind Configuration**

```bash
cat > tailwind.config.js << 'EOF'
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'dw-dark': '#0F0F1E',
        'dw-pink': '#FF006E',
        'dw-cyan': '#00D9FF',
        'dw-green': '#00FF6B',
        'dw-gold': '#FFD700',
      },
      fontFamily: {
        'poppins': ['Poppins', 'sans-serif'],
        'inter': ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
EOF
```

### **3. Global Styles**

```bash
cat > src/styles/globals.css << 'EOF'
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700;900&family=Inter:wght@400;600;700&display=swap');

:root {
  --color-bg: #0F0F1E;
  --color-pink: #FF006E;
  --color-cyan: #00D9FF;
  --color-green: #00FF6B;
  --color-gold: #FFD700;
  --color-text: #FFFFFF;
  --color-text-secondary: #A0A0B8;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body, #root {
  width: 100%;
  height: 100%;
}

body {
  background-color: var(--color-bg);
  color: var(--color-text);
  font-family: 'Inter', sans-serif;
  line-height: 1.5;
}

h1, h2, h3, h4, h5, h6 {
  font-family: 'Poppins', sans-serif;
  font-weight: 700;
}

button {
  cursor: pointer;
  border: none;
  font-family: 'Poppins', sans-serif;
  transition: all 0.2s ease-in-out;
}

button:hover {
  transform: translateY(-2px);
  filter: brightness(1.1);
}
EOF
```

### **4. Create Home Page**

```bash
cat > src/pages/Home.tsx << 'EOF'
import React from 'react';
import { useNavigate } from 'react-router-dom';

export function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-dw-dark text-white flex flex-col items-center justify-center p-4">
      <div className="text-center max-w-2xl">
        <h1 className="text-6xl font-black mb-4 bg-gradient-to-r from-dw-pink to-dw-cyan bg-clip-text text-transparent">
          🎡 DareWheel
        </h1>
        
        <p className="text-xl text-dw-text-secondary mb-8">
          The ultimate dual-mode Truth or Dare gaming experience
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/offline')}
            className="bg-dw-pink hover:bg-opacity-90 text-white font-bold py-4 px-6 rounded-lg text-lg"
          >
            🏠 Offline Mode
          </button>
          
          <button
            onClick={() => navigate('/online')}
            className="bg-dw-cyan hover:bg-opacity-90 text-black font-bold py-4 px-6 rounded-lg text-lg"
          >
            💻 Online Mode
          </button>
        </div>
      </div>
    </div>
  );
}
EOF

# Create App.tsx
cat > src/App.tsx << 'EOF'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import './styles/globals.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
    </Router>
  );
}

export default App;
EOF

# Update main.tsx
cat > src/main.tsx << 'EOF'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
EOF
```

### **5. Start Frontend**

```bash
npm install
npm run dev

# Expected output:
# ➜  Local:   http://localhost:5173/
# ➜  press h to show help
```

---

## 🐳 DOCKER SETUP

### **1. Create Dockerfile (Backend)**

```bash
cat > backend/Dockerfile << 'EOF'
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci

# Copy source code
COPY . .

# Build TypeScript
RUN npm run build

# Expose port
EXPOSE 5000

# Start application
CMD ["npm", "start"]
EOF
```

### **2. Create Dockerfile (Frontend)**

```bash
cat > frontend/Dockerfile << 'EOF'
FROM node:18-alpine AS builder

WORKDIR /app

COPY package*.json ./

RUN npm ci

COPY . .

RUN npm run build

FROM nginx:alpine

COPY --from=builder /app/dist /usr/share/nginx/html

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
EOF
```

### **3. Create docker-compose.yml**

```bash
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  # PostgreSQL Database
  postgres:
    image: postgres:14-alpine
    container_name: darewheel-postgres
    environment:
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: ${DB_NAME}
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER}"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Redis Cache
  redis:
    image: redis:7-alpine
    container_name: darewheel-redis
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Backend API
  backend:
    build: ./backend
    container_name: darewheel-backend
    environment:
      NODE_ENV: ${NODE_ENV}
      PORT: 5000
      DB_HOST: postgres
      DB_PORT: 5432
      REDIS_HOST: redis
      REDIS_PORT: 6379
    ports:
      - "5000:5000"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./backend/src:/app/src

  # Frontend App
  frontend:
    build: ./frontend
    container_name: darewheel-frontend
    ports:
      - "3000:80"
    depends_on:
      - backend
    environment:
      VITE_API_URL: http://backend:5000

volumes:
  postgres_data:

networks:
  default:
    name: darewheel-network
EOF
```

### **4. Start with Docker**

```bash
# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

---

## 🔄 DEVELOPMENT WORKFLOW

### **1. Daily Standup Checklist**

```bash
# Every morning:
□ Pull latest changes from develop branch
□ Update local database with new migrations
□ Check Slack/GitHub for blockers
□ Review task board (Trello/GitHub Projects)
□ Update status in team channel

# Command:
git checkout develop
git pull origin develop
npm install  # if package.json changed
npm run db:migrate  # if migrations added
```

### **2. Feature Development Cycle**

```bash
# 1. Create feature branch
git checkout develop
git pull origin develop
git checkout -b feature/game-spinning-wheel

# 2. Make changes
# ... edit code ...

# 3. Test locally
npm run dev        # backend
npm run dev        # frontend (in different terminal)

# 4. Commit changes
git add .
git commit -m "feat: add spinning wheel animation"

# 5. Push to GitHub
git push origin feature/game-spinning-wheel

# 6. Create Pull Request on GitHub
# Wait for code review
# Address feedback

# 7. Merge to develop
git checkout develop
git pull origin develop
git merge feature/game-spinning-wheel
git push origin develop

# 8. Delete feature branch
git branch -d feature/game-spinning-wheel
git push origin --delete feature/game-spinning-wheel
```

### **3. Code Review Process**

```
1. Developer pushes branch to GitHub
2. Opens Pull Request (PR) with description
3. Two developers review code:
   - Check logic & functionality
   - Verify tests pass
   - Check code style
   - Verify no security issues
4. Request changes OR approve
5. After approval, squash merge to develop
6. Deploy to staging for QA testing
7. If all tests pass, merge to main for production
```

### **4. Testing Workflow**

```bash
# Run unit tests
npm run test

# Run tests in watch mode (as you code)
npm run test:watch

# Run specific test file
npm run test -- testFile.test.ts

# Run with coverage
npm run test -- --coverage

# Lint code
npm run lint

# Type check
npm run type-check
```

---

## 📊 GIT STRATEGY

### **Branch Structure**

```
main (production)
  └── merge from release branches after testing
      └── tagged with version (v1.0.0)

develop (development)
  ├── feature/spinning-wheel
  ├── feature/chat-system
  ├── feature/authentication
  ├── bugfix/socket-connection
  └── ... (merged back after PR review)

hotfix/critical-bug (if needed)
  └── merges directly to main + develop
```

### **Commit Message Format**

```
Format: <type>(<scope>): <subject>

Types:
- feat: new feature
- fix: bug fix
- docs: documentation change
- style: code style change (no logic)
- refactor: code refactoring (no feature change)
- perf: performance improvement
- test: test addition/modification
- chore: build/dependency update

Example commits:
feat(wheel): add spinning animation with easing
fix(chat): resolve message ordering issue
docs(api): update endpoint documentation
refactor(auth): simplify token validation logic
```

### **Release Process**

```bash
# When ready to release (e.g., after 2 weeks)
# 1. Create release branch
git checkout -b release/v1.0.0

# 2. Update version numbers
# package.json version: 1.0.0

# 3. Update changelog
cat > CHANGELOG.md << 'EOF'
# v1.0.0 - March 2026

## Features
- Spinning wheel animation
- Chat system
- Authentication

## Bug Fixes
- Socket connection issue

## Breaking Changes
None
EOF

# 4. Commit release
git add .
git commit -m "chore: release v1.0.0"

# 5. Tag release
git tag -a v1.0.0 -m "Release version 1.0.0"

# 6. Merge to main
git checkout main
git merge release/v1.0.0

# 7. Merge back to develop
git checkout develop
git merge release/v1.0.0

# 8. Push everything
git push origin main develop --tags

# 9. Clean up
git branch -d release/v1.0.0
```

---

## ✅ TESTING & QA

### **Backend Testing**

```bash
# Create test file
cat > backend/src/__tests__/api.test.ts << 'EOF'
import request from 'supertest';
import { app } from '../index';

describe('Health Check', () => {
  it('should return health status', async () => {
    const response = await request(app)
      .get('/health')
      .expect(200);

    expect(response.body).toHaveProperty('status', 'ok');
  });
});
EOF

# Run tests
npm run test
```

### **Frontend Testing**

```bash
# Install testing library
npm install -D @testing-library/react @testing-library/jest-dom vitest

# Create test file
cat > src/__tests__/Home.test.tsx << 'EOF'
import { render, screen } from '@testing-library/react';
import { Home } from '../pages/Home';

describe('Home Page', () => {
  it('renders title', () => {
    render(<Home />);
    expect(screen.getByText(/DareWheel/i)).toBeInTheDocument();
  });
});
EOF

# Run tests
npm run test
```

### **API Testing with Postman**

```
1. Download Postman
2. Import API collection
3. Test endpoints:
   - GET /health
   - POST /auth/register
   - POST /auth/login
   - GET /game/questions/:mode
   - POST /game/room/create
4. Verify responses
```

---

## 🚀 FIRST WEEK CHECKLIST

```
Day 1-2: Setup
□ Clone repository
□ Install all dependencies
□ Setup databases (PostgreSQL + Redis)
□ Create .env files
□ Start backend & frontend locally
□ Verify both running on localhost

Day 3-4: Basic Features
□ Create user authentication system
□ Build home page UI
□ Create offline/online mode selection
□ Build spinning wheel component (basic)
□ Test locally

Day 5: Integration
□ Connect frontend to backend API
□ Test authentication flow
□ Setup Socket.io connection
□ Create basic game room
□ Deploy to staging

Day 6-7: Polish & Testing
□ Write unit tests
□ Run QA testing
□ Fix bugs
□ Document API endpoints
□ Prepare for week 2
```

---

## 📞 GETTING HELP

### **If Something Breaks**

```bash
# 1. Check logs
npm run dev  # terminal output

# 2. Check database
psql -U darewheel_user -d darewheel_dev -c "\dt"

# 3. Check Redis
redis-cli ping

# 4. Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# 5. Reset database
psql -U darewheel_user -d darewheel_dev -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"
npm run db:migrate

# 6. Check for port conflicts
lsof -i :5000  # backend
lsof -i :3000  # frontend
```

### **Useful Commands**

```bash
# Backend
npm run dev           # Start development server
npm run build         # Build TypeScript
npm run test          # Run tests
npm run lint          # Lint code
npm run db:migrate    # Run database migrations
npm run db:seed       # Seed database

# Frontend
npm run dev           # Start Vite dev server
npm run build         # Build for production
npm run preview       # Preview production build
npm run test          # Run tests

# Docker
docker-compose up -d      # Start all services
docker-compose down       # Stop all services
docker-compose logs -f    # View logs
docker-compose ps         # Check status
```

---

## 📝 TEAM CHECKLIST - BEFORE FIRST STANDUP

Every team member should complete:

```
□ Fork repository on GitHub
□ Clone to local machine
□ Create development branch
□ Install Node.js, npm, PostgreSQL, Redis
□ Create .env files from .env.example
□ Run npm install (both frontend & backend)
□ Start PostgreSQL & Redis
□ Run npm run dev (backend)
□ Run npm run dev (frontend)
□ Verify http://localhost:3000 loads
□ Verify http://localhost:5000/health returns JSON
□ Create GitHub SSH key for pushing
□ Join Slack channel
□ Review architecture documentation
□ Review task board
□ Ask questions in team channel
```

---

## ⏱️ ESTIMATED TIMELINE

```
Week 1: Foundation (Authentication + UI)
Week 2: Core Features (Wheel + Game Logic)
Week 3: Multiplayer (Socket.io + Rooms)
Week 4: Offline Mode

Week 5: Online Mode
Week 6: Chat System
Week 7: Gamification (Points/Streaks)
Week 8: Testing & Refinement

Week 9: Deployment
Week 10: Launch Prep
Week 11-12: Buffer & Fixes
Week 13-16: Polish & Optimization

Total: 4 Months (16 Weeks)
```

---

## 🎯 READY TO BUILD

**Everything is set up. Time to start coding! 🚀**

Next steps:
1. ✅ Complete environment setup
2. ✅ Start backend (npm run dev)
3. ✅ Start frontend (npm run dev)
4. ✅ First team standup
5. ✅ Assign tasks from task board
6. ✅ Begin development

**Good luck! The team is ready! 💪**

---

**Document Version**: 1.0  
**Status**: Development Kickoff  
**Date**: March 27, 2026  
**Duration**: 4 Months to MVP

---

END OF KICKOFF GUIDE
