# 🌍 DAREWHEEL - Internationalization & Multi-Language Strategy

**Version:** 1.0  
**Date:** March 2026  
**Focus:** User-Friendly, Inclusive, All Languages  
**Scope:** Complete i18n Architecture + 200+ Questions per Language

---

## 📋 TABLE OF CONTENTS

1. [Executive Summary](#executive-summary)
2. [Supported Languages](#supported-languages)
3. [i18n Architecture](#i18n-architecture)
4. [Language Switching UI/UX](#language-switching-uiux)
5. [Complete Translations](#complete-translations)
6. [Database Design for Multi-Language](#database-design-for-multi-language)
7. [Cultural Considerations](#cultural-considerations)
8. [Implementation Strategy](#implementation-strategy)
9. [Quality Assurance](#quality-assurance)
10. [Timeline & Resources](#timeline--resources)

---

## 🎯 EXECUTIVE SUMMARY

DareWheel's multi-language support enables **global accessibility** while maintaining **cultural relevance**. Using native scripts (NOT romanization), we support users in their preferred language seamlessly.

**Core Philosophy:**
```
INCLUSIVE > COOL
ACCESSIBLE > TRENDY
NATIVE SCRIPTS > ROMANIZATION

Why?
- Proper language respect
- Accessibility for all users (including elderly, non-tech-savvy)
- Professional brand image
- Legal compliance (accessibility standards)
- Better user experience for native speakers
- Universal keyboard support
```

---

## 🌐 SUPPORTED LANGUAGES

### **Phase 1: MVP Launch (11 Languages)**

| Language | Native Name | Script | Native Speakers | Total Reach | Priority |
|----------|-------------|--------|-----------------|-------------|----------|
| English | English | Latin | 370M | 1.5B+ | 1 (Tier 1) |
| Hindi | हिन्दी | Devanagari | 340M | 600M+ | 1 (Tier 1) |
| Tamil | தமிழ் | Tamil | 75M | 90M+ | 2 (Tier 1) |
| Telugu | తెలుగు | Telugu | 70M | 85M+ | 2 (Tier 1) |
| Kannada | ಕನ್ನಡ | Kannada | 45M | 50M+ | 2 (Tier 2) |
| Marathi | मराठी | Devanagari | 83M | 95M+ | 2 (Tier 2) |
| Spanish | Español | Latin | 460M | 500M+ | 1 (Tier 1) |
| French | Français | Latin | 280M | 300M+ | 1 (Tier 1) |
| German | Deutsch | Latin | 130M | 145M+ | 2 (Tier 2) |
| Portuguese | Português | Latin | 250M | 270M+ | 2 (Tier 2) |
| Japanese | 日本語 | Kanji/Hiragana/Katakana | 125M | 130M+ | 3 (Tier 2) |

**Total Reach: 3.5 BILLION people**

### **Phase 2: Extended Support (6+ More Languages)**

```
Chinese (Mandarin) - 1B speakers
Korean - 82M speakers
Italian - 85M speakers
Russian - 258M speakers
Gujarati - 60M speakers
Thai - 70M speakers
Vietnamese - 85M speakers
Polish - 45M speakers
Turkish - 88M speakers
Arabic - 310M speakers (future consideration)
```

---

## 🛠️ i18n ARCHITECTURE

### **Tech Stack for Multi-Language**

```
Frontend:
├── react-i18next (React framework)
├── i18next-browser-languagedetector (Auto-detect)
├── i18next-http-loader (Load translations dynamically)
├── i18next-localstorage-backend (Cache translations)
└── Intl API (For date/time/currency formatting)

Backend:
├── i18next with Node.js
├── Database translations (for dynamic content)
└── REST API with language parameter

File Structure:
locales/
├── en/ (English)
├── hi/ (Hindi)
├── ta/ (Tamil)
├── te/ (Telugu)
├── kn/ (Kannada)
├── mr/ (Marathi)
├── es/ (Spanish)
├── fr/ (French)
├── de/ (German)
├── pt/ (Portuguese)
└── ja/ (Japanese)

Each locale contains:
├── common.json (UI labels, buttons)
├── game.json (Game-specific text)
├── questions.json (Game questions - 200+)
├── blog.json (Blog content)
├── terms.json (Terms & Conditions)
├── errors.json (Error messages)
└── notifications.json (System messages)
```

### **Language Detection Logic**

```javascript
// Auto-detection order (smart fallback)
1. User saved preference (localStorage)
2. Browser language setting
3. Device operating system language
4. Geographic location (IP-based)
5. Default to English

Example:
- Indian user, first visit → Detects Hindi
- US user → Detects English
- Spanish user → Detects Spanish
- User changes preference → Saves to localStorage
- Preference persists across sessions
```

### **File Structure Example**

```
locales/
├── en/
│   ├── common.json
│   ├── game.json
│   ├── questions.json
│   ├── blog.json
│   ├── terms.json
│   ├── errors.json
│   └── notifications.json
├── hi/
│   ├── common.json
│   ├── game.json
│   ├── questions.json
│   ├── blog.json
│   ├── terms.json
│   ├── errors.json
│   └── notifications.json
├── ta/
├── te/
├── kn/
├── mr/
├── es/
├── fr/
├── de/
├── pt/
└── ja/
```

---

## 🎨 LANGUAGE SWITCHING UI/UX

### **Design Principle: Simple, Accessible, Non-Intrusive**

```
Option 1: Dropdown in Header (RECOMMENDED)
┌────────────────────────────────────────────────┐
│ DareWheel    [English ▼] [🌙] [🔔] [👤]        │
└────────────────────────────────────────────────┘
- Click dropdown
- See all 11 languages
- Select and auto-switch
- Persists across sessions

Option 2: Settings Panel (Alternative)
Header: [DareWheel] [⚙️]
        ↓
Settings:
├── Language: [English ▼]
├── Theme: [Dark/Light]
├── Sound: [On/Off]
└── Notifications: [On/Off]

Option 3: Footer Links (Secondary)
Footer: ... | English | हिन्दी | தமிழ் | తెలుగు | ...
        (Clickable language flags)
```

### **Language Selector Design**

```jsx
// React Component Example
import { useTranslation } from 'react-i18next';

function LanguageSelector() {
  const { i18n } = useTranslation();
  
  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'hi', name: 'हिन्दी', flag: '🇮🇳' },
    { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'te', name: 'తెలుగు', flag: '🇮🇳' },
    { code: 'kn', name: 'ಕನ್ನಡ', flag: '🇮🇳' },
    { code: 'mr', name: 'मराठी', flag: '🇮🇳' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'pt', name: 'Português', flag: '🇵🇹' },
    { code: 'ja', name: '日本語', flag: '🇯🇵' },
  ];
  
  return (
    <select 
      value={i18n.language} 
      onChange={(e) => i18n.changeLanguage(e.target.value)}
      className="language-selector"
    >
      {languages.map(lang => (
        <option key={lang.code} value={lang.code}>
          {lang.flag} {lang.name}
        </option>
      ))}
    </select>
  );
}
```

### **Visual Design**

```
LANGUAGE SELECTOR STYLING:
- Background: #1A1A2E (matches dark theme)
- Text: #FFFFFF (white)
- Hover: #FF006E (pink accent)
- Border: 2px solid #00D9FF (cyan)
- Font: Poppins 500, 14px
- Padding: 8px 12px
- Border-radius: 6px
- Cursor: pointer
- Smooth transition: 200ms

When language changes:
1. Instant UI update (no page reload)
2. Smooth fade transition (200ms)
3. All text updates simultaneously
4. Direction changes if RTL (future: Arabic, Urdu)
5. Toast notification: "Language changed to [Name]"
```

---

## 📝 COMPLETE TRANSLATIONS

### **File: locales/en/common.json**

```json
{
  "header": {
    "title": "DareWheel",
    "home": "Home",
    "blog": "Blog",
    "terms": "Terms & Conditions",
    "profile": "Profile"
  },
  "common": {
    "language": "Language",
    "theme": "Theme",
    "sound": "Sound",
    "notifications": "Notifications",
    "start": "Start Game",
    "create": "Create Room",
    "join": "Join Room",
    "cancel": "Cancel",
    "confirm": "Confirm",
    "save": "Save",
    "close": "Close",
    "next": "Next",
    "previous": "Previous",
    "yes": "Yes",
    "no": "No",
    "loading": "Loading...",
    "error": "Error",
    "success": "Success",
    "warning": "Warning",
    "info": "Info"
  },
  "modes": {
    "normal": "Normal",
    "flirty": "Flirty",
    "couples": "Couples",
    "hardcore": "Hardcore",
    "family_friendly": "Family-Friendly",
    "own": "Own Mode"
  },
  "buttons": {
    "start_game": "Start Game",
    "join_room": "Join Room",
    "create_room": "Create Room",
    "select_mode": "Select Mode",
    "submit": "Submit",
    "skip": "Skip",
    "pause": "Pause",
    "resume": "Resume",
    "quit": "Quit Game",
    "share": "Share",
    "report": "Report",
    "block": "Block User"
  },
  "footer": {
    "copyright": "© 2026 DareWheel. All rights reserved.",
    "privacy": "Privacy Policy",
    "terms": "Terms & Conditions",
    "contact": "Contact Us",
    "about": "About Us"
  }
}
```

### **File: locales/hi/common.json (Hindi)**

```json
{
  "header": {
    "title": "DareWheel",
    "home": "होम",
    "blog": "ब्लॉग",
    "terms": "नियम और शर्तें",
    "profile": "प्रोफाइल"
  },
  "common": {
    "language": "भाषा",
    "theme": "थीम",
    "sound": "ध्वनि",
    "notifications": "सूचनाएं",
    "start": "गेम शुरू करें",
    "create": "रूम बनाएं",
    "join": "रूम में शामिल हों",
    "cancel": "रद्द करें",
    "confirm": "पुष्टि करें",
    "save": "सहेजें",
    "close": "बंद करें",
    "next": "अगला",
    "previous": "पिछला",
    "yes": "हाँ",
    "no": "नहीं",
    "loading": "लोड हो रहा है...",
    "error": "त्रुटि",
    "success": "सफलता",
    "warning": "चेतावनी",
    "info": "जानकारी"
  },
  "modes": {
    "normal": "सामान्य",
    "flirty": "फ्लर्टी",
    "couples": "कपल्स",
    "hardcore": "हार्डकोर",
    "family_friendly": "पारिवारिक मित्र",
    "own": "अपना मोड"
  },
  "buttons": {
    "start_game": "गेम शुरू करें",
    "join_room": "रूम में शामिल हों",
    "create_room": "रूम बनाएं",
    "select_mode": "मोड चुनें",
    "submit": "जमा करें",
    "skip": "छोड़ें",
    "pause": "विराम",
    "resume": "फिर से शुरू करें",
    "quit": "गेम छोड़ें",
    "share": "साझा करें",
    "report": "रिपोर्ट करें",
    "block": "ब्लॉक करें"
  },
  "footer": {
    "copyright": "© 2026 DareWheel। सर्वाधिकार सुरक्षित।",
    "privacy": "गोपनीयता नीति",
    "terms": "नियम और शर्तें",
    "contact": "हमसे संपर्क करें",
    "about": "हमारे बारे में"
  }
}
```

### **File: locales/ta/common.json (Tamil)**

```json
{
  "header": {
    "title": "DareWheel",
    "home": "முகப்பு",
    "blog": "வலைப்பதிவு",
    "terms": "விதிமுறைகள் மற்றும் நிபந்தனைகள்",
    "profile": "சுயவிவரம்"
  },
  "common": {
    "language": "மொழி",
    "theme": "கருப்பொருள்",
    "sound": "ஒலி",
    "notifications": "அறிவிப்புகள்",
    "start": "விளையாட்டு தொடங்கவும்",
    "create": "அறையை உருவாக்கவும்",
    "join": "அறையில் சேரவும்",
    "cancel": "ரத்து செய்யவும்",
    "confirm": "உறுதிப்படுத்தவும்",
    "save": "சேமிக்கவும்",
    "close": "மூடவும்",
    "next": "அடுத்தது",
    "previous": "முந்தைய",
    "yes": "ஆம்",
    "no": "இல்லை",
    "loading": "ஏற்றுகிறது...",
    "error": "பிழை",
    "success": "வெற்றி",
    "warning": "எச்சரிக்கை",
    "info": "தகவல்"
  },
  "modes": {
    "normal": "சாதாரணம்",
    "flirty": "பாசபுரமான",
    "couples": "ஜோடிகள்",
    "hardcore": "கடுமையான",
    "family_friendly": "குடும்பத்திற்கு ஏற்ற",
    "own": "சொந்த பயன்முறை"
  },
  "buttons": {
    "start_game": "விளையாட்டு தொடங்கவும்",
    "join_room": "அறையில் சேரவும்",
    "create_room": "அறையை உருவாக்கவும்",
    "select_mode": "பயன்முறையைத் தேர்ந்தெடுக்கவும்",
    "submit": "சமர்ப்பிக்கவும்",
    "skip": "தவிர்க்கவும்",
    "pause": "இடைநிறுத்தம்",
    "resume": "மீண்டும் தொடங்கவும்",
    "quit": "விளையாட்டை விட்டு வெளியேறவும்",
    "share": "பகிர்ந்து கொள்ளவும்",
    "report": "அறிக்கை செய்யவும்",
    "block": "தடைசெய்யவும்"
  },
  "footer": {
    "copyright": "© 2026 DareWheel. அனைத்து உரிமைகளும் reserved.",
    "privacy": "தனியுரிமை கொள்கை",
    "terms": "விதிமுறைகள் மற்றும் நிபந்தனைகள்",
    "contact": "எங்களைத் தொடர்பு கொள்ளவும்",
    "about": "எங்களைப் பற்றி"
  }
}
```

### **File: locales/te/common.json (Telugu)**

```json
{
  "header": {
    "title": "DareWheel",
    "home": "హోమ్",
    "blog": "బ్లాగ్",
    "terms": "నిబంధనలు మరియు షరతులు",
    "profile": "ప్రొఫైల్"
  },
  "common": {
    "language": "భాష",
    "theme": "థీమ్",
    "sound": "సౌండ్",
    "notifications": "నోటిఫికేషన్లు",
    "start": "గేమ్ ప్రారంభించండి",
    "create": "రూమ్ సృష్టించండి",
    "join": "రూమ్‌లో చేరండి",
    "cancel": "రద్దు చేయండి",
    "confirm": "నిశ్చితం చేయండి",
    "save": "సేవ్ చేయండి",
    "close": "మూయండి",
    "next": "తరువాత",
    "previous": "గతం",
    "yes": "అవును",
    "no": "లేదు",
    "loading": "లోడ్ అవుతోంది...",
    "error": "ఎర్రర్",
    "success": "సాఫల్యం",
    "warning": "హెచ్చరిక",
    "info": "సమాచారం"
  },
  "modes": {
    "normal": "సాధారణ",
    "flirty": "చెమటపాటు",
    "couples": "జంటలు",
    "hardcore": "హార్డ్‌కోర్",
    "family_friendly": "కుటుంబ సరసన",
    "own": "మీ స్వంత మోడ్"
  },
  "buttons": {
    "start_game": "గేమ్ ప్రారంభించండి",
    "join_room": "రూమ్‌లో చేరండి",
    "create_room": "రూమ్ సృష్టించండి",
    "select_mode": "మోడ్ ఎంచుకోండి",
    "submit": "సమర్పించండి",
    "skip": "దాటవేయండి",
    "pause": "పాజ్ చేయండి",
    "resume": "తిరిగి ప్రారంభించండి",
    "quit": "గేమ్ నుండి నిష్క్రమించండి",
    "share": "పంచుకోండి",
    "report": "నివేదించండి",
    "block": "నిరోధించండి"
  },
  "footer": {
    "copyright": "© 2026 DareWheel. అన్ని హక్కులు నిరక్షితం.",
    "privacy": "గోప్యతా విధానం",
    "terms": "నిబంధనలు మరియు షరతులు",
    "contact": "మమ్మల్ని సంప్రదించండి",
    "about": "ఎవరి గురించి"
  }
}
```

### **File: locales/es/common.json (Spanish)**

```json
{
  "header": {
    "title": "DareWheel",
    "home": "Inicio",
    "blog": "Blog",
    "terms": "Términos y Condiciones",
    "profile": "Perfil"
  },
  "common": {
    "language": "Idioma",
    "theme": "Tema",
    "sound": "Sonido",
    "notifications": "Notificaciones",
    "start": "Comenzar Juego",
    "create": "Crear Sala",
    "join": "Unirse a Sala",
    "cancel": "Cancelar",
    "confirm": "Confirmar",
    "save": "Guardar",
    "close": "Cerrar",
    "next": "Siguiente",
    "previous": "Anterior",
    "yes": "Sí",
    "no": "No",
    "loading": "Cargando...",
    "error": "Error",
    "success": "Éxito",
    "warning": "Advertencia",
    "info": "Información"
  },
  "modes": {
    "normal": "Normal",
    "flirty": "Coqueto",
    "couples": "Parejas",
    "hardcore": "Extremo",
    "family_friendly": "Apto para Familias",
    "own": "Modo Personalizado"
  },
  "buttons": {
    "start_game": "Comenzar Juego",
    "join_room": "Unirse a Sala",
    "create_room": "Crear Sala",
    "select_mode": "Seleccionar Modo",
    "submit": "Enviar",
    "skip": "Saltar",
    "pause": "Pausar",
    "resume": "Reanudar",
    "quit": "Salir del Juego",
    "share": "Compartir",
    "report": "Reportar",
    "block": "Bloquear"
  },
  "footer": {
    "copyright": "© 2026 DareWheel. Todos los derechos reservados.",
    "privacy": "Política de Privacidad",
    "terms": "Términos y Condiciones",
    "contact": "Contáctenos",
    "about": "Acerca de Nosotros"
  }
}
```

---

## 🎮 GAME QUESTIONS - MULTI-LANGUAGE EXAMPLES

### **File: locales/en/questions.json (English - Excerpt)**

```json
{
  "normal": {
    "truths": [
      {
        "id": "norm_truth_001",
        "question": "What's your most embarrassing moment?",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_002",
        "question": "Have you ever lied to your friends? What about?",
        "difficulty": 2,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_003",
        "question": "What's your biggest insecurity?",
        "difficulty": 3,
        "crossModeCompatible": false
      }
    ],
    "dares": [
      {
        "id": "norm_dare_001",
        "question": "Sing the chorus of your favorite song out loud",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_dare_002",
        "question": "Do 10 push-ups right now",
        "difficulty": 2,
        "crossModeCompatible": true
      }
    ]
  },
  "flirty": {
    "truths": [
      {
        "id": "flirt_truth_001",
        "question": "Have you ever had a crush on two people at once?",
        "difficulty": 2,
        "crossModeCompatible": true
      }
    ],
    "dares": [
      {
        "id": "flirt_dare_001",
        "question": "Text your crush a flirty emoji",
        "difficulty": 1,
        "crossModeCompatible": false
      }
    ]
  }
}
```

### **File: locales/hi/questions.json (Hindi - Excerpt)**

```json
{
  "normal": {
    "truths": [
      {
        "id": "norm_truth_001",
        "question": "आपका सबसे शर्मनाक पल कौन सा है?",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_002",
        "question": "क्या आपने अपने दोस्तों से कभी झूठ बोला है?",
        "difficulty": 2,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_003",
        "question": "आपकी सबसे बड़ी असुरक्षा क्या है?",
        "difficulty": 3,
        "crossModeCompatible": false
      }
    ],
    "dares": [
      {
        "id": "norm_dare_001",
        "question": "अपने पसंदीदा गीत के कोरस को जोर से गाएं",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_dare_002",
        "question": "अभी 10 पुश-अप्स करें",
        "difficulty": 2,
        "crossModeCompatible": true
      }
    ]
  }
}
```

### **File: locales/ta/questions.json (Tamil - Excerpt)**

```json
{
  "normal": {
    "truths": [
      {
        "id": "norm_truth_001",
        "question": "உங்களின் மிகவும் சங்கடமான தருணம் என்ன?",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_002",
        "question": "நீங்கள் எப்போதாவது உங்கள் நண்பர்களிடம் பொய் சொன்னீர்களா?",
        "difficulty": 2,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_003",
        "question": "உங்களின் மிகப்பெரிய பாதுகாப்பு என்ன?",
        "difficulty": 3,
        "crossModeCompatible": false
      }
    ],
    "dares": [
      {
        "id": "norm_dare_001",
        "question": "உங்கள் பிடித்தமான பாடலின் குரல் வெளியில் பாடுங்கள்",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_dare_002",
        "question": "இப்போதே 10 தள்ளுதல் செய்யுங்கள்",
        "difficulty": 2,
        "crossModeCompatible": true
      }
    ]
  }
}
```

### **File: locales/te/questions.json (Telugu - Excerpt)**

```json
{
  "normal": {
    "truths": [
      {
        "id": "norm_truth_001",
        "question": "మీ అత్యంత ఇ為్ష్టకరమైన క్షణం ఏది?",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_002",
        "question": "మీరు ఎప్పుడైనా మీ స్నేహితులకు అబద్ధం చెప్పారా?",
        "difficulty": 2,
        "crossModeCompatible": true
      },
      {
        "id": "norm_truth_003",
        "question": "మీ అతిపెద్ద అసురక్ష ఏది?",
        "difficulty": 3,
        "crossModeCompatible": false
      }
    ],
    "dares": [
      {
        "id": "norm_dare_001",
        "question": "మీ ఇష్టమైన పాట యొక్క సంగీతం గట్టిగా పాడండి",
        "difficulty": 1,
        "crossModeCompatible": true
      },
      {
        "id": "norm_dare_002",
        "question": "ఇప్పుడు 10 పుష్-అప్‌లు చేయండి",
        "difficulty": 2,
        "crossModeCompatible": true
      }
    ]
  }
}
```

---

## 💾 DATABASE DESIGN FOR MULTI-LANGUAGE

### **PostgreSQL Table: translations**

```sql
CREATE TABLE translations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key VARCHAR(255) NOT NULL,
  language_code VARCHAR(10) NOT NULL,
  context VARCHAR(50), -- 'common', 'game', 'blog', 'terms', 'errors'
  translation_text TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  translated_by UUID REFERENCES users(id),
  reviewed BOOLEAN DEFAULT FALSE,
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMP,
  UNIQUE(key, language_code, context),
  INDEX idx_language ON translations(language_code),
  INDEX idx_context ON translations(context),
  INDEX idx_key ON translations(key)
);
```

### **PostgreSQL Table: supported_languages**

```sql
CREATE TABLE supported_languages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  language_code VARCHAR(10) UNIQUE NOT NULL,
  language_name VARCHAR(100) NOT NULL,
  native_name VARCHAR(100) NOT NULL,
  script_type VARCHAR(50), -- 'Latin', 'Devanagari', 'Tamil', 'Telugu', etc.
  native_speakers INT,
  total_reach INT,
  is_active BOOLEAN DEFAULT TRUE,
  sort_order INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed data:
INSERT INTO supported_languages VALUES
  (gen_random_uuid(), 'en', 'English', 'English', 'Latin', 370000000, 1500000000, TRUE, 1, NOW()),
  (gen_random_uuid(), 'hi', 'Hindi', 'हिन्दी', 'Devanagari', 340000000, 600000000, TRUE, 2, NOW()),
  (gen_random_uuid(), 'ta', 'Tamil', 'தமிழ்', 'Tamil', 75000000, 90000000, TRUE, 3, NOW()),
  (gen_random_uuid(), 'te', 'Telugu', 'తెలుగు', 'Telugu', 70000000, 85000000, TRUE, 4, NOW()),
  (gen_random_uuid(), 'kn', 'Kannada', 'ಕನ್ನಡ', 'Kannada', 45000000, 50000000, TRUE, 5, NOW()),
  (gen_random_uuid(), 'mr', 'Marathi', 'मराठी', 'Devanagari', 83000000, 95000000, TRUE, 6, NOW()),
  (gen_random_uuid(), 'es', 'Spanish', 'Español', 'Latin', 460000000, 500000000, TRUE, 7, NOW()),
  (gen_random_uuid(), 'fr', 'French', 'Français', 'Latin', 280000000, 300000000, TRUE, 8, NOW()),
  (gen_random_uuid(), 'de', 'German', 'Deutsch', 'Latin', 130000000, 145000000, TRUE, 9, NOW()),
  (gen_random_uuid(), 'pt', 'Portuguese', 'Português', 'Latin', 250000000, 270000000, TRUE, 10, NOW()),
  (gen_random_uuid(), 'ja', 'Japanese', '日本語', 'Kanji/Hiragana/Katakana', 125000000, 130000000, TRUE, 11, NOW());
```

### **User Language Preferences**

```sql
ALTER TABLE users ADD COLUMN preferred_language VARCHAR(10) DEFAULT 'en';
ALTER TABLE users ADD FOREIGN KEY (preferred_language) 
  REFERENCES supported_languages(language_code);

-- Example:
UPDATE users SET preferred_language = 'hi' WHERE user_id = '...';
```

---

## 🌏 CULTURAL CONSIDERATIONS

### **Language-Specific Guidelines**

| Language | Considerations | Special Rules |
|----------|-----------------|----------------|
| **English** | Standard | None |
| **Hindi** | Pan-India, respectful | Use formal words in questions |
| **Tamil** | South India, prideful culture | Respect Tamil identity, use proper script |
| **Telugu** | South India, friendly tone | Warm, approachable language |
| **Kannada** | South India, growing tech | Balance formal & casual |
| **Marathi** | Western India, culturally diverse | Inclusive, neutral language |
| **Spanish** | Latin America + Spain | Use Spanish (Spain) standard, not just Latin American |
| **French** | Europe + Africa | Formal, elegant language |
| **German** | Europe + Business | Professional tone |
| **Portuguese** | Brazil + Portugal | Use Brazilian Portuguese (larger market) |
| **Japanese** | Asia, tech-forward | Polite, respectful language (Keigo) |

### **Translation Quality Guidelines**

```
✅ DO:
1. Use native speakers for translations
2. Test all text in actual mobile/desktop apps
3. Have professional linguists review
4. Consider cultural humor (may not translate)
5. Use formal language in serious contexts
6. Maintain tone consistency across languages
7. Test all special characters and scripts
8. Ensure accessibility (screen readers work)

❌ DON'T:
1. Use Google Translate for final copy
2. Directly transliterate English humor
3. Use romanization (write in native scripts)
4. Mix formal and casual tone inconsistently
5. Assume literal translations work
6. Ignore cultural sensitivities
7. Forget about right-to-left languages (future)
8. Use generic translations
```

---

## 🚀 IMPLEMENTATION STRATEGY

### **Phase 1: MVP Launch (4 Months)**

```
Month 1:
- Set up i18n architecture (react-i18next)
- Create 11 language JSON file structure
- Implement language detector
- Build language selector component

Month 2:
- Translate common.json to all 11 languages
- Translate game.json to all 11 languages
- QA testing (character rendering, overflow issues)
- Professional linguist review (10 languages)

Month 3:
- Translate questions.json (200+ per language)
- Translate blog.json (50+ articles per language)
- Translate terms.json (legal documents)
- Translate error messages, notifications

Month 4:
- Final QA across all languages
- Character rendering on all devices
- RTL support prep (future)
- Launch with 11 languages
```

### **Phase 2: Extended Support (6 Months)**

```
Months 5-6:
- Add Chinese (Mandarin)
- Add Korean
- Add Italian
- Add Russian
- Add Gujarati
- Add Thai
- = 17 languages total

Plus:
- Community translations (crowdsourced)
- Professional translation service integration
```

### **DevOps for Multi-Language**

```
CI/CD Pipeline:
1. Code commit → Translation files updated
2. Automated tests:
   - All translations valid JSON
   - No missing translation keys
   - Character encoding correct
   - No placeholder text left
3. Professional review required
4. Deploy to staging
5. Manual QA across devices
6. Deploy to production

Monitoring:
- Track language usage statistics
- Monitor for missing translations
- Collect user feedback per language
- A/B test translations if needed
```

---

## ✅ QUALITY ASSURANCE

### **Translation QA Checklist**

```
For Each Language:
☐ All text translates without truncation
☐ Line breaks work correctly
☐ Special characters render properly
☐ Dates/times format correctly
☐ Numbers display correctly
☐ Emojis work across all platforms
☐ Mobile layout doesn't break
☐ Desktop layout doesn't break
☐ No hardcoded English text remains
☐ Button sizes accommodate longer text
☐ RTL ready (if applicable in future)
☐ Keyboard input works correctly
☐ Copy/paste functionality works
☐ Screen reader compatibility
☐ Professional native speaker review
```

### **Testing Matrix**

```
Test across:
Devices:
- iPhone (latest 2 versions)
- Android phones (latest 2 versions)
- iPad/tablets
- Desktop (Windows, Mac, Linux)

Browsers:
- Chrome, Firefox, Safari, Edge
- Mobile browsers (Chrome, Safari)

Languages:
- All 11 languages
- Test in order: EN → HI → TA → TE → all

Scenarios:
- First time user (auto-detect language)
- Returning user (load saved preference)
- Language switching mid-game
- Special characters in user input
- Long text in questions
```

---

## 📊 LANGUAGE STATISTICS & TARGETING

### **Expected User Distribution (Phase 1)**

```
By Language (Estimated):
English: 35% (370M potential, 50M+ DAU target)
Hindi: 25% (340M potential, 35M+ DAU)
Tamil: 12% (75M speakers, 10M+ DAU)
Telugu: 10% (70M speakers, 8M+ DAU)
Spanish: 10% (460M potential, 5M+ DAU)
Others (Kannada, Marathi, French, German, Portuguese, Japanese): 8%

Growth Strategy:
Q1: Focus on India (EN + HI + South Indian)
Q2: Expand to Europe (FR, DE, PT)
Q3: Target Latin America (ES)
Q4: Expand to Asia-Pacific (JP, others)
```

---

## 📅 TIMELINE & RESOURCES

### **Team Requirements**

```
Translation Team:
- 1 Project Manager (Multi-language)
- 11 Native Speakers (1 per language)
  - English (native English speaker)
  - Hindi (native Hindi speaker)
  - Tamil (native Tamil speaker)
  - Telugu (native Telugu speaker)
  - Kannada (native Kannada speaker)
  - Marathi (native Marathi speaker)
  - Spanish (native Spanish speaker)
  - French (native French speaker)
  - German (native German speaker)
  - Portuguese (native Portuguese speaker)
  - Japanese (native Japanese speaker)
- 2 Professional Linguists (QA & Review)
- 1 i18n Developer (React implementation)

Time Allocation:
- Setup & Architecture: 2 weeks
- Translations: 6 weeks (200+ questions × 11 languages)
- QA & Testing: 2 weeks
- Buffer/Fixes: 2 weeks
- Total: 12 weeks (3 months) for MVP

Cost Estimate:
- Native speakers: $15-25/hour × 40 hours each = $8,250
- Linguists (review): $50/hour × 80 hours = $4,000
- Developer: $40/hour × 100 hours = $4,000
- Project Manager: $35/hour × 80 hours = $2,800
- Tools/Services: ~$2,000
- **Total: ~$21,000 for MVP**
```

---

## 🔐 SECURITY & PRIVACY

### **Multi-Language Security**

```
✅ Ensure:
1. User language preference encrypted in DB
2. Translations stored securely
3. No injection attacks via translation text
4. Character encoding validated (UTF-8)
5. Input validation works across all scripts
6. Output sanitization works for all languages
7. No hardcoded credentials in translation files
8. Access logs track translation changes
9. Community translations moderated
10. Legal compliance per country
```

---

## 📈 SUCCESS METRICS

### **Multi-Language KPIs**

```
Engagement:
✅ Track DAU per language
✅ Session duration per language
✅ Feature usage by language
✅ Language switching frequency

Quality:
✅ Bug reports by language
✅ Translation accuracy feedback
✅ Character rendering issues
✅ User satisfaction per language

Growth:
✅ New users by language
✅ Retention rate by language
✅ Referral rate by language
✅ In-game spending by language (future)

Targets (6 months):
- 1M+ total users
- 11 languages fully supported
- <0.5% translation issues
- 4.5+ rating across all regions
```

---

## 🎯 FINAL RECOMMENDATIONS

```
✅ IMPLEMENT MULTI-LANGUAGE SUPPORT:

Why:
1. Reach 3.5B+ potential users
2. Cultural respect and inclusivity
3. User-friendly native scripts (not romanization)
4. Competitive advantage in South Asia
5. Professional, global brand image
6. Accessibility compliance
7. Easy to expand in future

Phase 1: 11 languages (MVP)
Phase 2: 17+ languages (growth)
Phase 3: 25+ languages (global)

Priority Order:
1. English (foundation)
2. Hindi (largest Indian market)
3. Tamil (South India + diaspora)
4. Telugu (South India + tech hub)
5. Spanish (global reach)
6. French (Europe)
7. Others (Kannada, Marathi, German, Portuguese, Japanese)

This positions DareWheel as:
🌍 TRULY GLOBAL platform
🌍 CULTURALLY INCLUSIVE brand
🌍 ACCESSIBLE to all users
🌍 LEADER in multi-language gaming
```

---

## 📝 NEXT STEPS

1. ✅ Approve multi-language strategy
2. ✅ Hire translation team (11 native speakers)
3. ✅ Finalize i18n architecture
4. ✅ Begin translation work (Month 2)
5. ✅ Integrate with development pipeline
6. ✅ QA testing across languages
7. ✅ Launch with 11 languages

---

**Document Version**: 1.0  
**Last Updated**: March 27, 2026  
**Status**: Ready for Implementation  
**Estimated Budget**: ~$21,000 for MVP Phase  
**Timeline**: 3 months (integrated with main development)

---

END OF DOCUMENT
